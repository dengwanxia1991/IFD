import torch
import torch.nn as nn
import os
from . import utils_kl as solver_utils
from utils.utils import to_cuda, to_onehot
from torch import optim
from . import clustering_kl
from discrepancy.cdd import CDD
from math import ceil as ceil
from .base_solver import BaseSolver
from copy import deepcopy
import torch.nn.functional as F
import math
import numpy as np
from torch.autograd import Variable
from losses import SupConLoss

def exp_lr_scheduler(optimizer, iter_num, gamma, power, lr=0.001, weight_decay=0.0005):
    """Decay learning rate by a factor of 0.1 every lr_decay_epoch epochs."""
    lr = lr * (1 + gamma * iter_num) ** (-power)
    i=0
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr * param_group['lr_mult']
        param_group['weight_decay'] = weight_decay * param_group['decay_mult']
        i+=1

    return optimizer

def joint_opt_loss(preds, soft_labels):
    # introduce prior prob distribution p
    p = torch.ones(31).cuda() / 31

    prob = F.softmax(preds, dim=1)
    prob_avg = torch.mean(prob, dim=0)

    # ignore constant
    L_c = -torch.mean(torch.sum(soft_labels * F.log_softmax(preds, dim=1), dim=1))
    L_p = -torch.sum(torch.log(prob_avg) * p)
    L_e = -torch.mean(torch.sum(prob * F.log_softmax(preds, dim=1), dim=1))


    loss = L_c + 0.1 * L_p + L_e

    return loss


def loss_func(feat, cluster_centers):
    q = 1.0 / (1.0 + torch.sum((feat.unsqueeze(1) - cluster_centers) ** 2, dim=2) / 1)
    q = q ** (1 + 1.0) / 2.0
    q = (q.t() / torch.sum(q, dim=1)).t()

    weight = q ** 2 / torch.sum(q, dim=0)
    p = (weight.t() / torch.sum(weight, dim=1)).t()

    log_q = torch.log(q)
    loss = F.kl_div(log_q, p)
    return loss


def TarDisClusterLoss(epoch, output, target, softmax=True, beta=1):
    if softmax:
        prob_p = F.softmax(output, dim=1)
    else:
        prob_p = output / output.sum(1, keepdim=True)

    prob_q1 = torch.cuda.FloatTensor(prob_p.size()).fill_(0)
    prob_q1.scatter_(1, target.unsqueeze(1), torch.ones(prob_p.size(0), 1).cuda())  # assigned pseudo labels
    if epoch == 0:
        prob_q = prob_q1
    else:
        prob_q2 = prob_p / prob_p.sum(0, keepdim=True).pow(0.5)
        prob_q2 /= prob_q2.sum(1, keepdim=True)
        prob_q = (1 - beta) * prob_q1 + beta * prob_q2

    if softmax:
        loss = - (prob_q * F.log_softmax(output, dim=1)).sum(1).mean()
    else:
        loss = - (prob_q * prob_p.log()).sum(1).mean()

    return loss



class CANSolver(BaseSolver):
    def __init__(self, net, dataloader, bn_domain_map={}, resume=None, **kwargs):
        super(CANSolver, self).__init__(net, dataloader, \
                      bn_domain_map=bn_domain_map, resume=resume, **kwargs)

        if len(self.bn_domain_map) == 0:
            self.bn_domain_map = {self.source_name: 0, self.target_name: 1}

        self.clustering_source_name = 'clustering_' + self.source_name
        self.clustering_target_name = 'clustering_' + self.target_name

        assert('categorical' in self.train_data)

        num_layers = len(self.net.FC) + 1
        self.cdd = CDD(kernel_num=self.opt.CDD.KERNEL_NUM, kernel_mul=self.opt.CDD.KERNEL_MUL,
                  num_layers=num_layers, num_classes=self.opt.DATASET.NUM_CLASSES, 
                  intra_only=self.opt.CDD.INTRA_ONLY)

        self.discrepancy_key = 'intra' if self.opt.CDD.INTRA_ONLY else 'cdd'
        self.clustering = clustering_kl.Clustering(self.opt.CLUSTERING.EPS,
                                        self.opt.CLUSTERING.FEAT_KEY, 
                                        self.opt.CLUSTERING.BUDGET)

        self.clustered_target_samples = {}

    def complete_training(self):
        if self.loop >= self.opt.TRAIN.MAX_LOOP:
            return True

        if 'target_centers' not in self.history or \
                'ts_center_dist' not in self.history or \
                'target_labels' not in self.history:
            return False

        if len(self.history['target_centers']) < 2 or \
		len(self.history['ts_center_dist']) < 1 or \
		len(self.history['target_labels']) < 2:
           return False

        # target centers along training
        target_centers = self.history['target_centers']
        eval1 = torch.mean(self.clustering.Dist.get_dist(target_centers[-1], 
			target_centers[-2])).item()

        # target-source center distances along training
        eval2 = self.history['ts_center_dist'][-1].item()

        # target labels along training
        path2label_hist = self.history['target_labels']
        paths = self.clustered_target_samples['data']
        num = 0
        for path in paths:
            pre_label = path2label_hist[-2][path]
            cur_label = path2label_hist[-1][path]
            if pre_label != cur_label:
                num += 1
        eval3 = 1.0 * num / len(paths)

        return (eval1 < self.opt.TRAIN.STOP_THRESHOLDS[0] and \
                eval2 < self.opt.TRAIN.STOP_THRESHOLDS[1] and \
                eval3 < self.opt.TRAIN.STOP_THRESHOLDS[2])

    def solve(self):
        stop = False
        alpha = 0.1
        self.lam1 = 0.3
        self.lam2 = 0.1
        self.cdd = 0.01
        self.best_accu = 0
        self.loss_results = []
        self.accu_results = []
        if self.resume:
            self.iters += 1
            self.loop += 1

        while True: 
            # updating the target label hypothesis through clustering
            with torch.no_grad():
                #self.update_ss_alignment_loss_weight()
                print('Clustering based on %s...' % self.source_name)
                self.update_labels()
                self.clustered_target_samples = self.clustering.samples

                if self.clustered_target_samples is not None and \
                              self.clustered_target_samples['gt'] is not None:
                    preds = to_onehot(self.clustered_target_samples['label'], 
                                                self.opt.DATASET.NUM_CLASSES)
                    gts = self.clustered_target_samples['gt']
                    res = self.model_eval(preds, gts)
                    print('Clustering %s: %.4f' % (self.opt.EVAL_METRIC, res))

                # check if meet the stop condition
                stop = self.complete_training()
                if stop: break
                
                # filtering the clustering results
                target_hypt, filtered_classes = self.filtering()

                # update dataloaders
                self.construct_categorical_dataloader(target_hypt, filtered_classes)
                # update train data setting
                self.compute_iters_per_loop(filtered_classes)

            # k-step update of network parameters through forward-backward process
            alpha = self.update_network(filtered_classes,alpha)
            self.loop += 1

        print('Training Done!')
        
    def update_labels(self):
        net = self.net
        net.eval()
        opt = self.opt

        source_dataloader = self.train_data[self.clustering_source_name]['loader']
        net.set_bn_domain(self.bn_domain_map[self.source_name])

        source_centers = solver_utils.get_centers(net, 
		source_dataloader, self.opt.DATASET.NUM_CLASSES, 
                self.opt.CLUSTERING.FEAT_KEY)

        init_target_centers = source_centers
        # if self.iters ==0 and self.loop ==0:
        #     init_target_centers = source_centers
        # else:
        #     init_target_centers = self.clustering.centers

        target_dataloader = self.train_data[self.clustering_target_name]['loader']
        net.set_bn_domain(self.bn_domain_map[self.target_name])
        self.clustering.set_init_centers(init_target_centers)

        self.clustering.feature_clustering(net, target_dataloader)
        self.clustering.centers = Variable(torch.cuda.FloatTensor(self.clustering.centers))

    def filtering(self):
        threshold = self.opt.CLUSTERING.FILTERING_THRESHOLD
        min_sn_cls = self.opt.TRAIN.MIN_SN_PER_CLASS
        target_samples = self.clustered_target_samples

        # filtering the samples
        chosen_samples = solver_utils.filter_samples(
		target_samples, threshold=threshold)

        # filtering the classes
        filtered_classes = solver_utils.filter_class(
		chosen_samples['label'], min_sn_cls, self.opt.DATASET.NUM_CLASSES)

        print('The number of filtered classes: %d.' % len(filtered_classes))
        return chosen_samples, filtered_classes

    def construct_categorical_dataloader(self, samples, filtered_classes):
        # update self.dataloader
        target_classwise = solver_utils.split_samples_classwise(
			samples, self.opt.DATASET.NUM_CLASSES)

        dataloader = self.train_data['categorical']['loader']
        classnames = dataloader.classnames
        dataloader.class_set = [classnames[c] for c in filtered_classes]
        dataloader.target_paths = {classnames[c]: target_classwise[c]['data'] \
                      for c in filtered_classes}
        dataloader.num_selected_classes = min(self.opt.TRAIN.NUM_SELECTED_CLASSES, len(filtered_classes))
        dataloader.construct()

    def CAS(self):
        samples = self.get_samples('categorical')
        source_samples = []
        target_samples = []

        source_samples_0 = samples['Img_source_0']
        source_samples_1 = samples['Img_source_1']
        source_sample_paths = samples['Path_source']
        source_nums = [len(paths) for paths in source_sample_paths]
        source_nums *= 2

        source_samples += source_samples_0
        source_samples += source_samples_1

        target_samples_0 = samples['Img_target_0']
        target_samples_1 = samples['Img_target_1']
        target_sample_paths = samples['Path_target']
        target_nums = [len(paths) for paths in target_sample_paths]
        target_nums *= 2

        target_samples += target_samples_0
        target_samples += target_samples_1
        
        source_sample_labels = samples['Label_source_0']
        # source_sample_labels_1 = samples['Label_source_1']
        #
        # source_sample_labels += source_sample_labels_0
        # source_sample_labels += source_sample_labels_1



        target_sample_labels = samples['Label_target_0']
        # target_sample_labels_1 = samples['Label_target_1']
        # target_sample_labels +=target_sample_labels_0
        # target_sample_labels += target_sample_labels_1


        self.selected_classes = [labels[0].item() for labels in source_sample_labels]

        assert(self.selected_classes ==
               [labels[0].item() for labels in  target_sample_labels])

        return source_samples, source_nums, source_sample_labels, target_samples, target_nums, target_sample_labels
            
    def prepare_feats(self, feats):
        return [feats[key] for key in feats if key in self.opt.CDD.ALIGNMENT_FEAT_KEYS]

    def compute_iters_per_loop(self, filtered_classes):
        self.iters_per_loop = int(len(self.train_data['categorical']['loader'])) * self.opt.TRAIN.UPDATE_EPOCH_PERCENTAGE
        print('Iterations in one loop: %d' % (self.iters_per_loop))

    def update_network(self, filtered_classes, alpha):
        # initial configuration
        stop = False
        update_iters = 0
        contra_criterion = SupConLoss(temperature=0.01)

        # update learning rate
        self.update_lr_iter()



        self.optimizer.param_groups += [{'params': self.clustering.centers, 'lr_mult': 1.0, 'lr': 0.001,
                                         'weight_decay': 0.0005, 'momentum': 0.9, 'dampening': 0, 'nesterov': False}]
        self.train_data['categorical']['iterator'] = \
            iter(self.train_data['categorical']['loader'])

        i = 0

        while i <= len(self.train_data['categorical']['loader']):
            self.update_hyper()
            # set the status of network
            self.net.train()
            self.net.zero_grad()

            # 1) class-aware sampling
            source_samples_cls, source_nums_cls, source_sample_labels, \
            target_samples_cls, target_nums_cls, target_sample_labels = self.CAS()

            # 2) forward and compute the loss
            source_cls_concat = torch.cat([samples
                                           for samples in source_samples_cls], dim=0)
            target_cls_concat = torch.cat([samples
                                           for samples in target_samples_cls], dim=0)

            source_label_concat = torch.cat([to_cuda(samples)
                                             for samples in source_sample_labels], dim=0)

            target_label_concat = torch.cat([to_cuda(samples)
                                             for samples in target_sample_labels], dim=0)
            source_cls_concat = to_cuda(source_cls_concat[0:len(source_label_concat)])
            target_cls_concat = to_cuda(target_cls_concat[0:len(target_label_concat)])


            self.net.set_bn_domain(self.bn_domain_map[self.source_name])
            feats_source = self.net(source_cls_concat)
            self.net.set_bn_domain(self.bn_domain_map[self.target_name])
            feats_target = self.net(target_cls_concat)


            logits_source = feats_source['logits']



            logits_target = feats_target['logits']
            features_target = feats_target['feat']

            prob_pred = (1 + (features_target.unsqueeze(1) - self.clustering.centers.unsqueeze(0)).pow(2).sum(
                2) / 1).pow(- (1 + 1) / 2)
            cluster_loss = TarDisClusterLoss(self.loop, prob_pred, target_label_concat, softmax=False, beta=1) + \
                           TarDisClusterLoss(self.loop, logits_target, target_label_concat, softmax=True, beta=1)

            cluster_loss = cluster_loss

            # compute the cross-entropy loss
            ce_loss = self.CELoss(logits_source, source_label_concat)

            loss = ce_loss + cluster_loss
            loss.backward()



            self.optimizer.step()
            i +=1
        print('Train at (loop %d), classification_loss: %f, clustering_loss: %f' %
                  (self.loop, ce_loss, cluster_loss))


        self.train_data['categorical']['iterator'] = \
            iter(self.train_data['categorical']['loader'])
        i = 0
        while i <= len(self.train_data['categorical']['loader']):
            self.net.train()
            self.net.zero_grad()
            # update the network parameters
            # 1) class-aware sampling
            source_samples_cls, source_nums_cls, source_sample_labels, \
                   target_samples_cls, target_nums_cls, target_sample_labels = self.CAS()

            # 2) forward and compute the loss
            source_cls_concat = torch.cat([to_cuda(samples)
                        for samples in source_samples_cls], dim=0)
            target_cls_concat = torch.cat([to_cuda(samples)
                        for samples in target_samples_cls], dim=0)

            source_label_concat = torch.cat([to_cuda(samples)
                                           for samples in source_sample_labels], dim=0)
            target_label_concat = torch.cat([to_cuda(samples)
                                           for samples in target_sample_labels], dim=0)



            self.net.set_bn_domain(self.bn_domain_map[self.source_name])
            feats_source = self.net(source_cls_concat)
            self.net.set_bn_domain(self.bn_domain_map[self.target_name])
            feats_target = self.net(target_cls_concat)

            preds_source = feats_source['probs']

            preds_target  = feats_target['probs']

            preds_1 = torch.cat([preds_source[0:len(source_label_concat)], preds_target[0:len(target_label_concat)]], dim=0)
            preds_2 = torch.cat([preds_source[len(source_label_concat):len(preds_source)], preds_target[len(target_label_concat):len(preds_target)]], dim=0)

            labels = torch.cat([source_label_concat, target_label_concat], dim=0)
            preds = torch.cat([preds_1.unsqueeze(1), preds_2.unsqueeze(1)], dim=1)
            cdd_loss_1 = contra_criterion(preds, labels)
            cdd_loss_1 *= self.opt.CDD.LOSS_WEIGHT

            cdd_loss = cdd_loss_1
            cdd_loss.backward()
            # update the network
            self.optimizer.step()
            i +=1

        print('Train at (loop %d), cdd_loss: %f' %
                  (self.loop, cdd_loss_1))



        with torch.no_grad():
            self.net.set_bn_domain(self.bn_domain_map[self.target_name])
            accu,test_loss = self.test()
            # self.loss_results.append([self.iters,test_loss])
            # self.accu_results.append([self.iters, accu])
            # fname1 = './results/DFAC_AD_loss' + '.csv'
            # np.savetxt(fname1, np.asarray(a=self.loss_results, dtype=float), delimiter=',', fmt='%.4f')
            # fname2 = './results/DFAC_AD_acc' + '.csv'
            # np.savetxt(fname2, np.asarray(a=self.accu_results, dtype=float), delimiter=',', fmt='%.4f')
            if accu > self.best_accu:
                self.best_accu = accu
                # torch.save(self.net, './results/DFAC_AD' + '.pth')
            print('Test at (loop %d) with %s: %.4f. %.4f.' % (self.loop,
                       self.opt.EVAL_METRIC, accu, test_loss))
            print('Best accuracy: %.4f' % (self.best_accu))



