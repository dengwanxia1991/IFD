from torchvision import datasets, transforms
import torch
from data_list import ImageList

# def load_training_na(root_path, dir, batch_size):
#     start_center = (256 - 224 - 1) / 2
#     transform = transforms.Compose(
#         [transforms.Resize([256, 256]),
#          PlaceCrop(224, start_center, start_center),
#          transforms.ToTensor(),
#          # transforms.Normalize(mean=[0.485, 0.456, 0.406],
#          #                      std=[0.229, 0.224, 0.225])
#          transforms.Normalize(mean=[0.5, 0.5, 0.5],
#                               std=[0.5, 0.5, 0.5])
#          ])
#     data = datasets.ImageFolder(root=root_path + dir, transform=transform)
#     train_loader = torch.utils.data.DataLoader(data, batch_size=batch_size, shuffle=True, drop_last=True,num_workers=0)
#     return train_loader

def load_training_original(root_path, dir, batch_size):
    transform = transforms.Compose(
        [transforms.RandomResizedCrop(224),
         transforms.RandomHorizontalFlip(),
         transforms.ToTensor(),
         transforms.Normalize(mean=[0.485, 0.456, 0.406],
                              std=[0.229, 0.224, 0.225]),
         ])
    data = datasets.ImageFolder(root=root_path + dir, transform=transform)
    test_loader = torch.utils.data.DataLoader(data, batch_size=batch_size, shuffle=True,drop_last=True,num_workers=0)
    return test_loader

def load_testing_original(root_path, dir, batch_size):
    transform = transforms.Compose(
        [transforms.Resize([224, 224]),
         transforms.ToTensor(),
         transforms.Normalize(mean=[0.485, 0.456, 0.406],
                              std=[0.229, 0.224, 0.225]),
         ])
    data = datasets.ImageFolder(root=root_path + dir, transform=transform)
    test_loader = torch.utils.data.DataLoader(data, batch_size=batch_size, shuffle=True,drop_last=True,num_workers=0)
    return test_loader

class PlaceCrop(object):
    """Crops the given PIL.Image at the particular index.
    Args:
        size (sequence or int): Desired output size of the crop. If size is an
            int instead of sequence like (w, h), a square crop (size, size) is
            made.
    """

    def __init__(self, size, start_x, start_y):
        if isinstance(size, int):
            self.size = (int(size), int(size))
        else:
            self.size = size
        self.start_x = start_x
        self.start_y = start_y

    def __call__(self, img):
        """
        Args:
            img (PIL.Image): Image to be cropped.
        Returns:
            PIL.Image: Cropped image.
        """
        th, tw = self.size
        return img.crop((self.start_x, self.start_y, self.start_x + tw, self.start_y + th))

def load_training(root_path, dir, batch_size):
    transform = transforms.Compose(
        [transforms.Resize([256, 256]),
        transforms.RandomResizedCrop(224),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406],
                              std=[0.229, 0.224, 0.225])
        # transforms.Normalize(mean=[0.5, 0.5, 0.5],
        #                       std=[0.5, 0.5, 0.5])
         ])
    data = datasets.ImageFolder(root=root_path + dir, transform=transform)
    train_loader = torch.utils.data.DataLoader(data, batch_size=batch_size, shuffle=True, drop_last=True)
    return train_loader

# def load_target_training(root_path, dir, batch_size):
#     transform = transforms.Compose(
#         [transforms.Resize([256, 256]),
#          transforms.RandomResizedCrop(224),
#          transforms.RandomHorizontalFlip(),
#          transforms.ToTensor(),
#          transforms.Normalize(mean=[0.485, 0.456, 0.406],
#                               std=[0.229, 0.224, 0.225])
#          ])
#     data = datasets.ImageFolder(root=root_path + dir, transform=transform)
#     train_loader = torch.utils.data.DataLoader(data, batch_size=batch_size, shuffle=True, drop_last=True)
#     return train_loader
def load_testing(root_path, dir, batch_size):
    start_center = (256 - 224 - 1) / 2
    transform = transforms.Compose(
        [transforms.Resize([256, 256]),
         PlaceCrop(224,start_center,start_center),
         transforms.ToTensor(),
         transforms.Normalize(mean=[0.485, 0.456, 0.406],
                              std=[0.229, 0.224, 0.225])
         # transforms.Normalize(mean=[0.5, 0.5, 0.5],
         #                      std=[0.5, 0.5, 0.5])
         ])
    data = datasets.ImageFolder(root=root_path + dir, transform=transform)
    test_loader = torch.utils.data.DataLoader(data, batch_size=batch_size, shuffle=True)
    return test_loader

def load_training_IC(root_path, dir, batch_size):
    root=root_path + dir + '.txt'
    train_loader =  torch.utils.data.DataLoader(ImageList(open(root).readlines(), transform=transforms.Compose([
                            transforms.Resize([256, 256]),
                            transforms.RandomResizedCrop(224),
                            transforms.RandomHorizontalFlip(),
                            transforms.ToTensor(),
                            # transforms.Normalize(mean=[0.485, 0.456, 0.406],
                            #                       std=[0.229, 0.224, 0.225])

                            # transforms.Normalize(mean=[0.5, 0.5, 0.5],
                            #                      std=[0.5, 0.5, 0.5])
                            transforms.Normalize([0.5],[0.5])
                       ]), mode='L'), batch_size=batch_size, shuffle=True, num_workers=0)
    return train_loader

def load_testing_IC(root_path, dir, batch_size):
    root=root_path + dir + '.txt'
    start_center = (256 - 224 - 1) / 2
    test_loader =  torch.utils.data.DataLoader(ImageList(open(root).readlines(), transform=transforms.Compose([
                    transforms.Resize([256, 256]),
                    PlaceCrop(224, start_center, start_center),
                    transforms.ToTensor(),
                    # transforms.Normalize(mean=[0.485, 0.456, 0.406],
                    #                      std=[0.229, 0.224, 0.225])
                    # transforms.Normalize(mean=[0.5, 0.5, 0.5],
                    #                      std=[0.5, 0.5, 0.5])
                    transforms.Normalize([0.5], [0.5])
                       ]), mode='L'), batch_size=batch_size, shuffle=True, num_workers=0)
    return test_loader
