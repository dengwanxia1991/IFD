# _*_ coding:utf-8 -*-
#from sklearn.manifold import TSNE
#from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
#import tsnecuda
import os
import torch.backends.cudnn as cudnn
import torch.utils.data
import torchvision.utils as vutils
from torch.autograd import Variable
from torchvision import transforms
from torchvision import datasets
import data_loader
import numpy as np
import pickle
import torch.nn as nn
from sklearn.manifold import TSNE
from sklearn.metrics import mean_squared_error
from sklearn.metrics import mean_absolute_error


os.environ["CUDA_VISIBLE_DEVICES"] = "0,2,3"
#def rec_image(epoch,my_net):
cuda = True


if __name__=='__main__':
    # # load models
    # # my_file = os.path.join(model_root, 'svhn_mnist_Cmodel_epoch_' + str(50) + '.pth')
    # # with open(my_file, 'rb') as f:
    # #     my_net = pickle.load(f, encoding='latin1')
    #
    #
    model_resnet50 = torch.load(os.path.join('./results/' + 'EDFA_AW.pth'))
    model_resnet50 = torch.nn.DataParallel(model_resnet50).cuda()
    root_dir = '/root/DWX/data/office31/'

    datasetloader_source, datasetloader_target = data_loader.load_testing(root_dir, 'amazon', 96), \
                                             data_loader.load_testing(root_dir, 'webcam', 96)

    len_source = len(datasetloader_source)-1
    len_target = len(datasetloader_target)-1



    dataset_source_iter = iter(datasetloader_source)

    i = 0
    feat_source = []
    labels_source = []
    feat_target = []
    labels_target = []
    softmax_layer = nn.Softmax()

    while i <= len_source:

        data_source = dataset_source_iter.next()
        s_img, class_label = data_source

        if i % len_target == 0:
            dataset_target_iter = iter(datasetloader_target)
        data_target = dataset_target_iter.next()
        t_img, target_label = data_target

        if cuda:
            s_img = s_img.cuda()
            t_img = t_img.cuda()
            class_label = class_label.cuda()
            target_label = target_label.cuda()

        sv_img = Variable(s_img)
        tv_img = Variable(t_img)
        classv_label = Variable(class_label)
        target_label = Variable(target_label)

        pred_s_label = model_resnet50(sv_img)
        pred_t_label = model_resnet50(tv_img)




        feat_source.append(pred_s_label['logits'].data.cpu().numpy())
        labels_source.append(classv_label.data.cpu().numpy())
        feat_target.append(pred_t_label['logits'].data.cpu().numpy())
        labels_target.append(target_label.data.cpu().numpy())
        i += 1


    feat_source = np.concatenate(feat_source, 0)
    labels_source = np.concatenate(labels_source, 0)
    feat_target = np.concatenate(feat_target, 0)
    labels_target = np.concatenate(labels_target, 0)

    # mae = abs(mean_absolute_error(feat_source, labels_source)-mean_absolute_error(feat_target, labels_target))
    # print(mae*2)


    # print(2. * (1. - 2. * mae))

    fname1 = './results/EDFA-C_source_PAD_AW' + '.csv'
    fname2 = './results/EDFA-C_target_PAD_AW' + '.csv'
    np.savetxt(fname1, feat_source, delimiter=',',fmt='%.4f')
    np.savetxt(fname2, feat_target, delimiter=',', fmt='%.4f')

    from sklearn.model_selection import train_test_split
    import pandas as pd

    # Importing the dataset
    dataset1 = pd.read_csv('./results/EDFA-C_source_PAD_AW' + '.csv')
    X1 = dataset1
    y1=np.zeros(len(X1))

    dataset2 = pd.read_csv('./results/EDFA-C_target_PAD_AW' + '.csv')
    X2 = dataset2
    y2 = np.ones(len(X2))

    X1_train, X1_test, y1_train, y1_test = train_test_split(X1, y1, test_size=0.25, random_state=0)

    X2_train, X2_test, y2_train, y2_test = train_test_split(X2, y2, test_size=0.25, random_state=0)


    from sklearn.svm import SVC

    X_train = [X1_train,X2_train]
    X_train = np.concatenate(X_train,0)
    y_train = [y1_train,y2_train]
    y_train = np.concatenate(y_train, 0)

    inm = np.arange(len(X_train))
    np.random.shuffle(inm)
    inm = np.array(inm)

    classifier = SVC(kernel='rbf', random_state=0)
    X= X_train[inm]
    Y= y_train[inm]

    classifier.fit(X, Y)



    X_test = [X1_test, X2_test]
    X_test = np.concatenate(X_test, 0)
    y_test = [y1_test, y2_test]
    y_test = np.concatenate(y_test, 0)
    y_pred = classifier.predict(X_test)
    mae = mean_absolute_error(y_pred, y_test)
    print(mae)
    print(2. * (1. - 2. * mae))

    # JAN = 1.980
    # JAN_NL=1.706
    # JAN_DLSN=1.7769
    # DAN = 1.8299
    # DAN_NL= 2.368
    # DAN_DLSN=2.4705
    # Dcoral = 3.655
    # Dcoral_Nl=2.8129
    # Dcoral_DLSN=3.245
    # DDC=3.286
    # DDC_NL=3.428
    # DDC_DLSN=3.387
    # DANN = 1.45
    # DANN_nl= 1.807
    # DANN_dlsn=

    #CDAN =1.519
    #CDAN_NL =1.4859



